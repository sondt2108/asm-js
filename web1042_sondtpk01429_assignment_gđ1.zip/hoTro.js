function taoId() {
    var thoiGianHienTai = new Date().getTime();

    return thoiGianHienTai;
}